# ZODAS – Optimización de Clústeres Logísticos (Huila/Meta) – **MIP p‑mediana**

Este repositorio implementa **exclusivamente** un **modelo de optimización MIP** (programación lineal entera mixta)
del tipo **p‑mediana / facility location** para la conformación de clústeres municipales, **no** K‑Means.
La formulación sigue la estructura típica del documento RAP‑E (conjuntos/índices, parámetros, variables,
función objetivo y restricciones), resolviendo con **PuLP (CBC)**.

## Formulación (resumen)
**Conjuntos e índices**
- Municipios/Unidades de demanda: \( i \in I \)
- Candidatos a centroide: \( j \in J \) (en este caso, todos los municipios)

**Parámetros**
- \( d_{ij} \): distancia Haversine (km) entre municipio \( i \) y candidato \( j \)
- \( w_i \): producción (peso) en \( i \)
- \( p \): número de centroides a seleccionar (k)
- \( R \): radio máximo de asignación (si \( d_{ij} > R \Rightarrow x_{ij}=0 \))
- \( S \): separación mínima entre centroides (si \( d_{j_1 j_2} < S \Rightarrow y_{j_1} + y_{j_2} \le 1 \))
- (Opcional) **centroides fijos** \( \bar{J} \subseteq J \): \( y_j=1, \forall j \in \bar{J} \)

**Variables de decisión**
- \( y_j \in \{0,1\} \): 1 si \( j \) es centroide seleccionado
- \( x_{ij} \in \{0,1\} \): 1 si \( i \) se asigna al centroide \( j \)

**Función objetivo**
\[ \min \sum_{i\in I} \sum_{j\in J} w_i \; d_{ij} \; x_{ij} \]

**Restricciones**
1. Asignación única: \( \sum_{j\in J} x_{ij} = 1, \; \forall i \)
2. Enlace: \( x_{ij} \le y_j, \; \forall i,j \)
3. Cantidad de centroides: \( \sum_{j\in J} y_j = p \)
4. Radio máximo: si \( d_{ij} > R \Rightarrow x_{ij}=0 \) (se excluye el arco)
5. Separación entre centros: si \( d_{j_1 j_2} < S \Rightarrow y_{j_1} + y_{j_2} \le 1 \)
6. Centroides fijos: \( y_j = 1, \; \forall j \in \bar{J} \)

> **Nota:** Puedes extender con capacidades mín/máx por clúster o costos fijos por centro, si el documento lo requiere.

## Entradas
- `data/produccion_municipal_*.csv` con columnas:
  `departamento, municipio, lat, lon, producto, produccion`

## Ejecutar
```bash
pip install -r requirements.txt
streamlit run streamlit_app/app.py
```

## Qué muestra la app
- **Gráfico** costo vs número de clústeres (k)
- **Mapa** (pydeck) con agrupamiento por colores y centroides
- **Warnings** cuando hay infactibilidad (motivo)
- **Lista** de municipios por grupo con su centroide
